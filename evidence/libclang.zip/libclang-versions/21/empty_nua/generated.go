package probe

import "github.com/goplus/lib/c"

type Empty struct {
}
type TwoSame struct {
	A Empty
	B Empty
	X c.Int
}
