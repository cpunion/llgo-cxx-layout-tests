package probe

import (
	"github.com/goplus/lib/c"
	"github.com/goplus/lib/c/bitfield"
	"unsafe"
)

const XGoPackage = true

type Basic struct {
	_xgo_align  [0]uint32
	_xgo_bits_0 [1]uint8
	_           [3]uint8
}

// unsigned int a : 1
func (p *Basic) XGof_get_a() c.Uint {
	return c.Uint(bitfield.Unsigned(unsafe.Pointer(p), 0, 1))
}

// unsigned int a : 1
func (p *Basic) XGof_set_a(v c.Uint) {
	bitfield.Set(unsafe.Pointer(p), 0, 1, uint64(v))
}

// int b : 3
func (p *Basic) XGof_get_b() c.Int {
	return c.Int(bitfield.Signed(unsafe.Pointer(p), 1, 3))
}

// int b : 3
func (p *Basic) XGof_set_b(v c.Int) {
	bitfield.Set(unsafe.Pointer(p), 1, 3, uint64(v))
}

// unsigned int c : 4
func (p *Basic) XGof_get_c() c.Uint {
	return c.Uint(bitfield.Unsigned(unsafe.Pointer(p), 4, 4))
}

// unsigned int c : 4
func (p *Basic) XGof_set_c(v c.Uint) {
	bitfield.Set(unsafe.Pointer(p), 4, 4, uint64(v))
}
