package probe

import "github.com/goplus/lib/c"

type Empty struct {
}
type Single struct {
	E Empty
}
type EmptyArray struct {
	E [5]Empty
	X c.Int
}
