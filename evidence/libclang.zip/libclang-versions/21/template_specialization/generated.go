package probe

type Empty struct {
}
