package probe

import "github.com/goplus/lib/c"

type Base struct {
	X c.Int
	C c.Char
}
type Derived struct {
	Base
	D c.Char
}
