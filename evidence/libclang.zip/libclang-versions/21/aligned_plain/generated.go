package probe

import "github.com/goplus/lib/c"

type Aligned struct {
	X c.Int
}
type AlignedBox struct {
	Prefix c.Char
	Value  Aligned
	Suffix c.Char
}
