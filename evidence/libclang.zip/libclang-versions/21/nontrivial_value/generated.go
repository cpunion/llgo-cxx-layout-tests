package probe

import (
	"github.com/goplus/lib/c"
	_ "unsafe"
)

type Nontrivial struct {
	Value c.Int
}

//llgo:link (*Nontrivial).XGo_Dtor C._ZN10NontrivialD1Ev
func (this *Nontrivial) XGo_Dtor() {
}

//go:linkname _AcceptNontrivial C.accept_nontrivial
func _AcceptNontrivial(x Nontrivial) c.UlongLong
