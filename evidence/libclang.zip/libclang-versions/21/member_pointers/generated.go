package probe

import (
	"github.com/goplus/lib/c"
	"unsafe"
)

type Object struct {
	_xgo_vptr unsafe.Pointer
	Value     c.Int
}

//llgo:cdecl
type X_vtable_Object struct {
	F func(this *Object) c.Int
}

func (p *Object) XGo_vptr() *X_vtable_Object {
	return (*X_vtable_Object)(p._xgo_vptr)
}

//llgo:link (*Object).F C._ZN6Object1fEv
func (this *Object) F() c.Int {
	return 0
}
