package probe

import "github.com/goplus/lib/c"

type Packed struct {
	C c.Char
	X c.Int
}
