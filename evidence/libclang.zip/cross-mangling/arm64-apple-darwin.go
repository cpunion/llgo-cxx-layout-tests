package probe

import (
	"github.com/goplus/lib/c"
	_ "unsafe"
)

//go:linkname _AuditSymbol C.audit_symbol
func _AuditSymbol(value c.Int) c.Int
