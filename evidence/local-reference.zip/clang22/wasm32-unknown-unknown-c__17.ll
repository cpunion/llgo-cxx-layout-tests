; ModuleID = '/Users/lijie/source/goplus/llgo-cxx-layout-tests/probes/layout.cpp'
source_filename = "/Users/lijie/source/goplus/llgo-cxx-layout-tests/probes/layout.cpp"
target datalayout = "e-m:e-p:32:32-p10:8:8-p20:8:8-i64:64-i128:128-n32:64-S128-ni:1:10:20"
target triple = "wasm32-unknown-unknown"

%struct.Trivial = type { i32 }
%struct.Nontrivial = type { i32 }
%struct.TrivialABI = type { i32 }

$_ZN10TrivialABID2Ev = comdat any

@audit_facts = hidden constant [119 x i64] [i64 1, i64 1, i64 8, i64 4, i64 0, i64 1, i64 4, i64 4, i64 0, i64 1, i64 0, i64 4, i64 4, i64 0, i64 0, i64 1, i64 0, i64 1, i64 1, i64 4, i64 4, i64 0, i64 1, i64 0, i64 16, i64 8, i64 16, i64 8, i64 9, i64 1, i64 1, i64 8, i64 4, i64 4, i64 16, i64 16, i64 32, i64 16, i64 16, i64 12, i64 4, i64 8, i64 4, i64 4, i64 4, i64 4, i64 4, i64 0, i64 4, i64 4, i64 0, i64 1, i64 1, i64 8, i64 8, i64 6, i64 10, i64 1, i64 6, i64 24, i64 8, i64 4, i64 8, i64 9, i64 1, i64 1, i64 16, i64 16, i64 1, i64 8, i64 4, i64 8, i64 4, i64 5, i64 4, i64 4, i64 0, i64 4, i64 4, i64 1, i64 0, i64 12, i64 4, i64 12, i64 4, i64 24, i64 4, i64 40, i64 8, i64 20, i64 4, i64 8, i64 4, i64 4, i64 16, i64 4, i64 4, i64 8, i64 4, i64 8, i64 4, i64 8, i64 4, i64 4, i64 4, i64 4, i64 4, i64 4, i64 8, i64 8, i64 16, i64 16, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0], align 16

; Function Attrs: mustprogress noinline nounwind optnone
define hidden i32 @call_trivial(i32 %0) #0 {
  %2 = alloca %struct.Trivial, align 4
  %3 = alloca %struct.Trivial, align 4
  %4 = getelementptr inbounds nuw %struct.Trivial, ptr %3, i32 0, i32 0
  store i32 %0, ptr %4, align 4
  call void @llvm.memcpy.p0.p0.i32(ptr align 4 %2, ptr align 4 %3, i32 4, i1 false)
  %5 = getelementptr inbounds nuw %struct.Trivial, ptr %2, i32 0, i32 0
  %6 = load i32, ptr %5, align 4
  ret i32 %6
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i32(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i32, i1 immarg) #1

; Function Attrs: mustprogress noinline nounwind optnone
define hidden void @call_nontrivial(ptr dead_on_unwind noalias writable sret(%struct.Nontrivial) align 4 %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 4
  %4 = alloca ptr, align 4
  store ptr %0, ptr %3, align 4
  store ptr %1, ptr %4, align 4
  call void @llvm.memcpy.p0.p0.i32(ptr align 4 %0, ptr align 4 %1, i32 4, i1 false)
  ret void
}

; Function Attrs: mustprogress noinline nounwind optnone
define hidden i32 @call_trivial_abi(i32 %0) #0 {
  %2 = alloca %struct.TrivialABI, align 4
  %3 = alloca %struct.TrivialABI, align 4
  %4 = getelementptr inbounds nuw %struct.TrivialABI, ptr %3, i32 0, i32 0
  store i32 %0, ptr %4, align 4
  call void @llvm.memcpy.p0.p0.i32(ptr align 4 %2, ptr align 4 %3, i32 4, i1 false)
  %5 = call noundef ptr @_ZN10TrivialABID2Ev(ptr noundef nonnull align 4 dereferenceable(4) %3) #2
  %6 = getelementptr inbounds nuw %struct.TrivialABI, ptr %2, i32 0, i32 0
  %7 = load i32, ptr %6, align 4
  ret i32 %7
}

; Function Attrs: mustprogress noinline nounwind optnone
define linkonce_odr hidden noundef ptr @_ZN10TrivialABID2Ev(ptr noundef nonnull returned align 4 dereferenceable(4) %0) unnamed_addr #0 comdat {
  %2 = alloca ptr, align 4
  store ptr %0, ptr %2, align 4
  %3 = load ptr, ptr %2, align 4
  ret ptr %3
}

attributes #0 = { mustprogress noinline nounwind optnone "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext" }
attributes #1 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{!"Homebrew clang version 22.1.8"}
