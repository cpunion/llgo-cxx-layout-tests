; ModuleID = '/Users/lijie/source/goplus/llgo-cxx-layout-tests/probes/layout.cpp'
source_filename = "/Users/lijie/source/goplus/llgo-cxx-layout-tests/probes/layout.cpp"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-p:64:64-i32:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-pc-windows-msvc19.33.0"

%struct.Trivial = type { i32 }
%struct.Nontrivial = type { i32 }
%struct.TrivialABI = type { i32 }

$"??1Nontrivial@@QEAA@XZ" = comdat any

$"??1TrivialABI@@QEAA@XZ" = comdat any

@audit_facts = dso_local constant [119 x i64] [i64 1, i64 1, i64 12, i64 4, i64 8, i64 1, i64 8, i64 4, i64 0, i64 1, i64 4, i64 8, i64 4, i64 0, i64 1, i64 2, i64 4, i64 1, i64 1, i64 8, i64 4, i64 0, i64 1, i64 4, i64 16, i64 8, i64 24, i64 8, i64 16, i64 1, i64 1, i64 8, i64 4, i64 4, i64 16, i64 16, i64 32, i64 16, i64 16, i64 12, i64 4, i64 8, i64 8, i64 8, i64 4, i64 8, i64 4, i64 4, i64 8, i64 4, i64 4, i64 2, i64 1, i64 24, i64 8, i64 16, i64 11, i64 1, i64 7, i64 24, i64 8, i64 4, i64 8, i64 9, i64 1, i64 1, i64 16, i64 16, i64 1, i64 8, i64 4, i64 12, i64 4, i64 8, i64 4, i64 4, i64 0, i64 8, i64 4, i64 0, i64 4, i64 24, i64 8, i64 24, i64 8, i64 48, i64 8, i64 56, i64 8, i64 20, i64 4, i64 24, i64 8, i64 8, i64 32, i64 8, i64 4, i64 8, i64 4, i64 16, i64 8, i64 16, i64 4, i64 4, i64 4, i64 4, i64 4, i64 4, i64 8, i64 8, i64 16, i64 16, i64 0, i64 0, i64 0, i64 0, i64 4, i64 4, i64 0], align 16

; Function Attrs: mustprogress noinline nounwind optnone uwtable
define dso_local i32 @call_trivial(i64 %0) #0 {
  %2 = alloca %struct.Trivial, align 4
  %3 = alloca %struct.Trivial, align 4
  %4 = getelementptr inbounds nuw %struct.Trivial, ptr %3, i32 0, i32 0
  %5 = trunc i64 %0 to i32
  store i32 %5, ptr %4, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %2, ptr align 4 %3, i64 4, i1 false)
  %6 = getelementptr inbounds nuw %struct.Trivial, ptr %2, i32 0, i32 0
  %7 = load i32, ptr %6, align 4
  ret i32 %7
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: mustprogress noinline nounwind optnone uwtable
define dso_local void @call_nontrivial(ptr dead_on_unwind inreg noalias writable sret(%struct.Nontrivial) align 4 %0, i64 %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca %struct.Nontrivial, align 4
  store ptr %0, ptr %3, align 8
  %5 = getelementptr inbounds nuw %struct.Nontrivial, ptr %4, i32 0, i32 0
  %6 = trunc i64 %1 to i32
  store i32 %6, ptr %5, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %0, ptr align 4 %4, i64 4, i1 false)
  call void @"??1Nontrivial@@QEAA@XZ"(ptr noundef nonnull align 4 dereferenceable(4) %4) #2
  ret void
}

; Function Attrs: mustprogress noinline nounwind optnone uwtable
define linkonce_odr dso_local void @"??1Nontrivial@@QEAA@XZ"(ptr noundef nonnull align 4 dereferenceable(4) %0) unnamed_addr #0 comdat {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  ret void
}

; Function Attrs: mustprogress noinline nounwind optnone uwtable
define dso_local void @call_trivial_abi(ptr dead_on_unwind inreg noalias writable sret(%struct.TrivialABI) align 4 %0, i64 %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca %struct.TrivialABI, align 4
  store ptr %0, ptr %3, align 8
  %5 = getelementptr inbounds nuw %struct.TrivialABI, ptr %4, i32 0, i32 0
  %6 = trunc i64 %1 to i32
  store i32 %6, ptr %5, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %0, ptr align 4 %4, i64 4, i1 false)
  call void @"??1TrivialABI@@QEAA@XZ"(ptr noundef nonnull align 4 dereferenceable(4) %4) #2
  ret void
}

; Function Attrs: mustprogress noinline nounwind optnone uwtable
define linkonce_odr dso_local void @"??1TrivialABI@@QEAA@XZ"(ptr noundef nonnull align 4 dereferenceable(4) %0) unnamed_addr #0 comdat {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  ret void
}

attributes #0 = { mustprogress noinline nounwind optnone uwtable "frame-pointer"="reserved" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+v8a,-fmv" }
attributes #1 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nounwind }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6}
!llvm.ident = !{!7}

!0 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_14, file: !1, producer: "Homebrew clang version 22.1.8", isOptimized: false, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "/Users/lijie/source/goplus/llgo-cxx-layout-tests/probes/layout.cpp", directory: "/Users/lijie/source/goplus/llgo-cxx-layout-tests")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 1, !"wchar_size", i32 2}
!4 = !{i32 8, !"PIC Level", i32 2}
!5 = !{i32 7, !"uwtable", i32 2}
!6 = !{i32 7, !"frame-pointer", i32 3}
!7 = !{!"Homebrew clang version 22.1.8"}
