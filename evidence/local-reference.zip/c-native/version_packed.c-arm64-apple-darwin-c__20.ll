; ModuleID = '/Users/lijie/source/goplus/llgo-cxx-layout-tests/probes/version_packed.c'
source_filename = "/Users/lijie/source/goplus/llgo-cxx-layout-tests/probes/version_packed.c"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx28.0.0"

@audit_version_facts = constant [3 x i64] [i64 10, i64 1, i64 6], align 8

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 1}
!3 = !{i32 7, !"frame-pointer", i32 4}
!4 = !{!"Homebrew clang version 22.1.8"}
