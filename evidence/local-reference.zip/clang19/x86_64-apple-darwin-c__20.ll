; ModuleID = '/Users/lijie/source/goplus/llgo-cxx-layout-tests/probes/layout.cpp'
source_filename = "/Users/lijie/source/goplus/llgo-cxx-layout-tests/probes/layout.cpp"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-apple-macosx18.0.0"

%struct.Trivial = type { i32 }
%struct.Nontrivial = type { i32 }
%struct.TrivialABI = type { i32 }

@audit_facts = constant [119 x i64] [i64 1, i64 1, i64 8, i64 4, i64 0, i64 1, i64 4, i64 4, i64 0, i64 1, i64 0, i64 4, i64 4, i64 0, i64 0, i64 1, i64 0, i64 1, i64 1, i64 4, i64 4, i64 0, i64 1, i64 0, i64 16, i64 8, i64 16, i64 8, i64 9, i64 1, i64 1, i64 8, i64 4, i64 4, i64 16, i64 16, i64 32, i64 16, i64 16, i64 12, i64 4, i64 8, i64 8, i64 8, i64 4, i64 4, i64 4, i64 0, i64 4, i64 4, i64 0, i64 1, i64 1, i64 8, i64 8, i64 6, i64 10, i64 1, i64 6, i64 32, i64 8, i64 8, i64 16, i64 9, i64 1, i64 1, i64 16, i64 16, i64 1, i64 8, i64 4, i64 8, i64 4, i64 5, i64 4, i64 4, i64 0, i64 4, i64 4, i64 1, i64 0, i64 16, i64 8, i64 16, i64 8, i64 40, i64 8, i64 48, i64 8, i64 20, i64 4, i64 16, i64 8, i64 8, i64 24, i64 8, i64 8, i64 16, i64 8, i64 16, i64 8, i64 16, i64 4, i64 4, i64 4, i64 4, i64 4, i64 4, i64 8, i64 8, i64 16, i64 16, i64 4, i64 4, i64 16, i64 8, i64 0, i64 0, i64 0], align 16

; Function Attrs: mustprogress noinline nounwind optnone ssp uwtable
define i32 @call_trivial(i32 %0) #0 {
  %2 = alloca %struct.Trivial, align 4
  %3 = alloca %struct.Trivial, align 4
  %4 = getelementptr inbounds %struct.Trivial, ptr %3, i32 0, i32 0
  store i32 %0, ptr %4, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %2, ptr align 4 %3, i64 4, i1 false)
  %5 = getelementptr inbounds %struct.Trivial, ptr %2, i32 0, i32 0
  %6 = load i32, ptr %5, align 4
  ret i32 %6
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #1

; Function Attrs: mustprogress noinline nounwind optnone ssp uwtable
define void @call_nontrivial(ptr dead_on_unwind noalias writable sret(%struct.Nontrivial) align 4 %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %0, ptr align 4 %1, i64 4, i1 false)
  ret void
}

; Function Attrs: mustprogress noinline nounwind optnone ssp uwtable
define i32 @call_trivial_abi(i32 %0) #0 {
  %2 = alloca %struct.TrivialABI, align 4
  %3 = alloca %struct.TrivialABI, align 4
  %4 = getelementptr inbounds %struct.TrivialABI, ptr %3, i32 0, i32 0
  store i32 %0, ptr %4, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %2, ptr align 4 %3, i64 4, i1 false)
  call void @_ZN10TrivialABID1Ev(ptr noundef nonnull align 4 dereferenceable(4) %3) #2
  %5 = getelementptr inbounds %struct.TrivialABI, ptr %2, i32 0, i32 0
  %6 = load i32, ptr %5, align 4
  ret i32 %6
}

; Function Attrs: mustprogress noinline nounwind optnone ssp uwtable
define linkonce_odr void @_ZN10TrivialABID1Ev(ptr noundef nonnull align 4 dereferenceable(4) %0) unnamed_addr #0 align 2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  call void @_ZN10TrivialABID2Ev(ptr noundef nonnull align 4 dereferenceable(4) %3) #2
  ret void
}

; Function Attrs: mustprogress noinline nounwind optnone ssp uwtable
define linkonce_odr void @_ZN10TrivialABID2Ev(ptr noundef nonnull align 4 dereferenceable(4) %0) unnamed_addr #0 align 2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  ret void
}

attributes #0 = { mustprogress noinline nounwind optnone ssp uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="penryn" "target-features"="+cmov,+cx16,+cx8,+fxsr,+mmx,+sahf,+sse,+sse2,+sse3,+sse4.1,+ssse3,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nounwind }

!llvm.linker.options = !{}
!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{i32 7, !"frame-pointer", i32 2}
!4 = !{!"Homebrew clang version 19.1.7"}
