; ModuleID = '/Users/lijie/source/goplus/llgo-cxx-layout-tests/probes/empty.c'
source_filename = "/Users/lijie/source/goplus/llgo-cxx-layout-tests/probes/empty.c"
target datalayout = "e-m:o-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx18.0.0"

@audit_c_facts = constant [4 x i64] [i64 0, i64 1, i64 4, i64 0], align 8

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 1}
!3 = !{i32 7, !"frame-pointer", i32 1}
!4 = !{!"Homebrew clang version 19.1.7"}
