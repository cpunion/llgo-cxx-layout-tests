; ModuleID = '/Users/lijie/source/goplus/llgo-cxx-layout-tests/probes/empty.c'
source_filename = "/Users/lijie/source/goplus/llgo-cxx-layout-tests/probes/empty.c"
target datalayout = "e-m:w-p:64:64-i32:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-pc-windows-msvc19.33.0"

@audit_c_facts = dso_local constant [4 x i64] [i64 4, i64 1, i64 8, i64 4], align 8

!llvm.module.flags = !{!0, !1, !2}
!llvm.ident = !{!3}

!0 = !{i32 1, !"wchar_size", i32 2}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{!"Homebrew clang version 19.1.7"}
