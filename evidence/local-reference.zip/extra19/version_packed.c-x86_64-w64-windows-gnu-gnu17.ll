; ModuleID = '/Users/lijie/source/goplus/llgo-cxx-layout-tests/probes/version_packed.c'
source_filename = "/Users/lijie/source/goplus/llgo-cxx-layout-tests/probes/version_packed.c"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-w64-windows-gnu"

@audit_version_facts = dso_local constant [3 x i64] [i64 16, i64 4, i64 10], align 16

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 2}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{i32 1, !"MaxTLSAlign", i32 65536}
!4 = !{!"Homebrew clang version 19.1.7"}
