; ModuleID = '/Users/lijie/source/goplus/llgo-cxx-layout-tests/probes/empty.c'
source_filename = "/Users/lijie/source/goplus/llgo-cxx-layout-tests/probes/empty.c"
target datalayout = "e-m:e-p:32:32-Fi8-i64:64-v128:64:128-a:0:32-n32-S64"
target triple = "armv4t-unknown-none-eabi"

@audit_c_facts = dso_local constant [4 x i64] [i64 0, i64 1, i64 4, i64 0], align 8

!llvm.module.flags = !{!0, !1, !2}
!llvm.ident = !{!3}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 1, !"min_enum_size", i32 4}
!2 = !{i32 7, !"frame-pointer", i32 2}
!3 = !{!"Homebrew clang version 19.1.7"}
