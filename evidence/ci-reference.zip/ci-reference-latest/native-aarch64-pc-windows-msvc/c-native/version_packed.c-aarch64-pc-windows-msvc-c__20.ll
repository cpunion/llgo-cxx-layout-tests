; ModuleID = 'C:\a\llgo-cxx-layout-tests\llgo-cxx-layout-tests\probes\version_packed.c'
source_filename = "C:\\a\\llgo-cxx-layout-tests\\llgo-cxx-layout-tests\\probes\\version_packed.c"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-p:64:64-i32:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-pc-windows-msvc19.51.36260"

@audit_version_facts = dso_local constant [3 x i64] [i64 11, i64 1, i64 7], align 8

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6}
!llvm.ident = !{!7}

!0 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_14, file: !1, producer: "clang version 22.1.8 (https://github.com/llvm/llvm-project ca7933e47d3a3451d81e72ac174dcb5aa28b59d1)", isOptimized: false, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "C:\\a\\llgo-cxx-layout-tests\\llgo-cxx-layout-tests\\probes\\version_packed.c", directory: "C:\\a\\llgo-cxx-layout-tests\\llgo-cxx-layout-tests")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 1, !"wchar_size", i32 2}
!4 = !{i32 8, !"PIC Level", i32 2}
!5 = !{i32 7, !"uwtable", i32 2}
!6 = !{i32 7, !"frame-pointer", i32 3}
!7 = !{!"clang version 22.1.8 (https://github.com/llvm/llvm-project ca7933e47d3a3451d81e72ac174dcb5aa28b59d1)"}
