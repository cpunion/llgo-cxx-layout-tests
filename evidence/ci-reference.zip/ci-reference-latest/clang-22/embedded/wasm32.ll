; ModuleID = '/home/runner/work/llgo-cxx-layout-tests/llgo-cxx-layout-tests/probes/layout.cpp'
source_filename = "/home/runner/work/llgo-cxx-layout-tests/llgo-cxx-layout-tests/probes/layout.cpp"
target datalayout = "e-m:e-p:32:32-p10:8:8-p20:8:8-i64:64-i128:128-n32:64-S128-ni:1:10:20"
target triple = "wasm32-unknown-wasip1"

%struct.Nontrivial = type { i32 }

@audit_facts = hidden local_unnamed_addr constant [119 x i64] [i64 1, i64 1, i64 8, i64 4, i64 0, i64 1, i64 4, i64 4, i64 0, i64 1, i64 0, i64 4, i64 4, i64 0, i64 0, i64 1, i64 0, i64 1, i64 1, i64 4, i64 4, i64 0, i64 1, i64 0, i64 16, i64 8, i64 16, i64 8, i64 9, i64 1, i64 1, i64 8, i64 4, i64 4, i64 16, i64 16, i64 32, i64 16, i64 16, i64 12, i64 4, i64 8, i64 4, i64 4, i64 4, i64 4, i64 4, i64 0, i64 4, i64 4, i64 0, i64 1, i64 1, i64 8, i64 8, i64 6, i64 10, i64 1, i64 6, i64 24, i64 8, i64 4, i64 8, i64 9, i64 1, i64 1, i64 16, i64 16, i64 1, i64 8, i64 4, i64 8, i64 4, i64 5, i64 4, i64 4, i64 0, i64 4, i64 4, i64 1, i64 0, i64 12, i64 4, i64 12, i64 4, i64 24, i64 4, i64 40, i64 8, i64 20, i64 4, i64 8, i64 4, i64 4, i64 16, i64 4, i64 4, i64 8, i64 4, i64 8, i64 4, i64 8, i64 4, i64 4, i64 4, i64 4, i64 4, i64 4, i64 8, i64 8, i64 16, i64 16, i64 4, i64 4, i64 16, i64 8, i64 0, i64 0, i64 0], align 16

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define hidden i32 @call_trivial(i32 returned %0) local_unnamed_addr #0 {
  ret i32 %0
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite)
define hidden void @call_nontrivial(ptr dead_on_unwind noalias writable writeonly sret(%struct.Nontrivial) align 4 captures(none) initializes((0, 4)) %0, ptr noundef readonly captures(none) %1) local_unnamed_addr #1 {
  %3 = load i32, ptr %1, align 4, !tbaa !2
  store i32 %3, ptr %0, align 4, !tbaa !2
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define hidden i32 @call_trivial_abi(i32 returned %0) local_unnamed_addr #0 {
  ret i32 %0
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext" }
attributes #1 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext" }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{!"Ubuntu clang version 22.1.8 (++20260714014902+ca7933e47d3a-1~exp1~20260714135019.80)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C++ TBAA"}
