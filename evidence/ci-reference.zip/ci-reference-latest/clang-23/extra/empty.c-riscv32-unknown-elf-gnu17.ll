; ModuleID = '/home/runner/work/llgo-cxx-layout-tests/llgo-cxx-layout-tests/probes/empty.c'
source_filename = "/home/runner/work/llgo-cxx-layout-tests/llgo-cxx-layout-tests/probes/empty.c"
target datalayout = "e-m:e-p:32:32-i64:64-n32-S128"
target triple = "riscv32-unknown-unknown-elf"

@audit_c_facts = dso_local constant [4 x i64] [i64 0, i64 1, i64 4, i64 0], align 8

!llvm.module.flags = !{!0, !1, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"target-abi", !"ilp32"}
!1 = !{i32 6, !"riscv-isa", !2}
!2 = !{!"rv32i2p1_m2p0_a2p1_c2p0_zmmul1p0_zaamo1p0_zalrsc1p0_zca1p0"}
!3 = !{i32 7, !"frame-pointer", i32 2}
!4 = !{i32 8, !"SmallDataLimit", i32 0}
!5 = !{!"Ubuntu clang version 23.1.5 (++20261023090852+395ba2c4d274-1~exp1~20261023090919.90)"}
