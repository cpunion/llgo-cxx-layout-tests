; ModuleID = '/home/runner/work/llgo-cxx-layout-tests/llgo-cxx-layout-tests/probes/layout.cpp'
source_filename = "/home/runner/work/llgo-cxx-layout-tests/llgo-cxx-layout-tests/probes/layout.cpp"
target datalayout = "e-m:e-p:32:32-i64:64-n32-S128"
target triple = "riscv32-unknown-unknown-elf"

%struct.Trivial = type { i32 }
%struct.Nontrivial = type { i32 }
%struct.TrivialABI = type { i32 }

$_ZN10TrivialABID2Ev = comdat any

@audit_facts = dso_local constant [119 x i64] [i64 1, i64 1, i64 8, i64 4, i64 0, i64 1, i64 4, i64 4, i64 0, i64 1, i64 0, i64 4, i64 4, i64 0, i64 0, i64 1, i64 0, i64 1, i64 1, i64 4, i64 4, i64 0, i64 1, i64 0, i64 16, i64 8, i64 16, i64 8, i64 9, i64 1, i64 1, i64 8, i64 4, i64 4, i64 16, i64 16, i64 32, i64 16, i64 16, i64 12, i64 4, i64 8, i64 4, i64 4, i64 4, i64 4, i64 4, i64 0, i64 4, i64 4, i64 0, i64 1, i64 1, i64 8, i64 8, i64 6, i64 10, i64 1, i64 6, i64 24, i64 8, i64 4, i64 8, i64 9, i64 1, i64 1, i64 16, i64 16, i64 1, i64 8, i64 4, i64 8, i64 4, i64 5, i64 4, i64 4, i64 0, i64 4, i64 4, i64 1, i64 0, i64 12, i64 4, i64 12, i64 4, i64 24, i64 4, i64 40, i64 8, i64 20, i64 4, i64 8, i64 4, i64 4, i64 16, i64 4, i64 4, i64 8, i64 4, i64 8, i64 4, i64 8, i64 4, i64 4, i64 4, i64 4, i64 4, i64 4, i64 8, i64 8, i64 16, i64 16, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0], align 8

; Function Attrs: mustprogress noinline nounwind optnone
define dso_local i32 @call_trivial(i32 %0) #0 {
  %2 = alloca %struct.Trivial, align 4
  %3 = alloca %struct.Trivial, align 4
  %4 = getelementptr inbounds %struct.Trivial, ptr %3, i32 0, i32 0
  store i32 %0, ptr %4, align 4
  call void @llvm.memcpy.p0.p0.i32(ptr align 4 %2, ptr align 4 %3, i32 4, i1 false)
  %5 = getelementptr inbounds %struct.Trivial, ptr %2, i32 0, i32 0
  %6 = load i32, ptr %5, align 4
  ret i32 %6
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i32(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i32, i1 immarg) #1

; Function Attrs: mustprogress noinline nounwind optnone
define dso_local void @call_nontrivial(ptr dead_on_unwind noalias writable sret(%struct.Nontrivial) align 4 %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 4
  %4 = alloca ptr, align 4
  store ptr %0, ptr %3, align 4
  store ptr %1, ptr %4, align 4
  call void @llvm.memcpy.p0.p0.i32(ptr align 4 %0, ptr align 4 %1, i32 4, i1 false)
  ret void
}

; Function Attrs: mustprogress noinline nounwind optnone
define dso_local i32 @call_trivial_abi(i32 %0) #0 {
  %2 = alloca %struct.TrivialABI, align 4
  %3 = alloca %struct.TrivialABI, align 4
  %4 = getelementptr inbounds %struct.TrivialABI, ptr %3, i32 0, i32 0
  store i32 %0, ptr %4, align 4
  call void @llvm.memcpy.p0.p0.i32(ptr align 4 %2, ptr align 4 %3, i32 4, i1 false)
  call void @_ZN10TrivialABID2Ev(ptr noundef nonnull align 4 dereferenceable(4) %3) #2
  %5 = getelementptr inbounds %struct.TrivialABI, ptr %2, i32 0, i32 0
  %6 = load i32, ptr %5, align 4
  ret i32 %6
}

; Function Attrs: mustprogress noinline nounwind optnone
define linkonce_odr dso_local void @_ZN10TrivialABID2Ev(ptr noundef nonnull align 4 dereferenceable(4) %0) unnamed_addr #0 comdat align 2 {
  %2 = alloca ptr, align 4
  store ptr %0, ptr %2, align 4
  %3 = load ptr, ptr %2, align 4
  ret void
}

attributes #0 = { mustprogress noinline nounwind optnone "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic-rv32" "target-features"="+32bit,+a,+c,+m,+relax,+zmmul,-b,-d,-e,-experimental-smmpm,-experimental-smnpm,-experimental-ssnpm,-experimental-sspm,-experimental-ssqosid,-experimental-supm,-experimental-zacas,-experimental-zalasr,-experimental-zicfilp,-experimental-zicfiss,-f,-h,-shcounterenw,-shgatpa,-shtvala,-shvsatpa,-shvstvala,-shvstvecd,-smaia,-smcdeleg,-smcsrind,-smepmp,-smstateen,-ssaia,-ssccfg,-ssccptr,-sscofpmf,-sscounterenw,-sscsrind,-ssstateen,-ssstrict,-sstc,-sstvala,-sstvecd,-ssu64xl,-svade,-svadu,-svbare,-svinval,-svnapot,-svpbmt,-v,-xcvalu,-xcvbi,-xcvbitmanip,-xcvelw,-xcvmac,-xcvmem,-xcvsimd,-xsfcease,-xsfvcp,-xsfvfnrclipxfqf,-xsfvfwmaccqqq,-xsfvqmaccdod,-xsfvqmaccqoq,-xsifivecdiscarddlone,-xsifivecflushdlone,-xtheadba,-xtheadbb,-xtheadbs,-xtheadcmo,-xtheadcondmov,-xtheadfmemidx,-xtheadmac,-xtheadmemidx,-xtheadmempair,-xtheadsync,-xtheadvdot,-xventanacondops,-xwchc,-za128rs,-za64rs,-zaamo,-zabha,-zalrsc,-zama16b,-zawrs,-zba,-zbb,-zbc,-zbkb,-zbkc,-zbkx,-zbs,-zca,-zcb,-zcd,-zce,-zcf,-zcmop,-zcmp,-zcmt,-zdinx,-zfa,-zfbfmin,-zfh,-zfhmin,-zfinx,-zhinx,-zhinxmin,-zic64b,-zicbom,-zicbop,-zicboz,-ziccamoa,-ziccif,-zicclsm,-ziccrse,-zicntr,-zicond,-zicsr,-zifencei,-zihintntl,-zihintpause,-zihpm,-zimop,-zk,-zkn,-zknd,-zkne,-zknh,-zkr,-zks,-zksed,-zksh,-zkt,-ztso,-zvbb,-zvbc,-zve32f,-zve32x,-zve64d,-zve64f,-zve64x,-zvfbfmin,-zvfbfwma,-zvfh,-zvfhmin,-zvkb,-zvkg,-zvkn,-zvknc,-zvkned,-zvkng,-zvknha,-zvknhb,-zvks,-zvksc,-zvksed,-zvksg,-zvksh,-zvkt,-zvl1024b,-zvl128b,-zvl16384b,-zvl2048b,-zvl256b,-zvl32768b,-zvl32b,-zvl4096b,-zvl512b,-zvl64b,-zvl65536b,-zvl8192b" }
attributes #1 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !4, !5}
!llvm.ident = !{!6}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 1, !"target-abi", !"ilp32"}
!2 = !{i32 6, !"riscv-isa", !3}
!3 = !{!"rv32i2p1_m2p0_a2p1_c2p0_zmmul1p0"}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{i32 8, !"SmallDataLimit", i32 8}
!6 = !{!"Ubuntu clang version 19.1.7 (++20250804090312+cd708029e0b2-1~exp1~20250804210325.79)"}
