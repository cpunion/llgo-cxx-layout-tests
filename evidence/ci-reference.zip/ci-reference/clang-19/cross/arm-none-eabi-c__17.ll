; ModuleID = '/home/runner/work/llgo-cxx-layout-tests/llgo-cxx-layout-tests/probes/layout.cpp'
source_filename = "/home/runner/work/llgo-cxx-layout-tests/llgo-cxx-layout-tests/probes/layout.cpp"
target datalayout = "e-m:e-p:32:32-Fi8-i64:64-v128:64:128-a:0:32-n32-S64"
target triple = "armv5e-unknown-none-eabi"

%struct.Trivial = type { i32 }
%struct.Nontrivial = type { i32 }
%struct.TrivialABI = type { i32 }

$_ZN10TrivialABID2Ev = comdat any

@audit_facts = dso_local constant [119 x i64] [i64 1, i64 1, i64 8, i64 4, i64 0, i64 1, i64 4, i64 4, i64 0, i64 1, i64 0, i64 4, i64 4, i64 0, i64 0, i64 1, i64 0, i64 1, i64 1, i64 4, i64 4, i64 0, i64 1, i64 0, i64 16, i64 8, i64 16, i64 8, i64 9, i64 1, i64 1, i64 8, i64 4, i64 4, i64 16, i64 16, i64 32, i64 16, i64 16, i64 12, i64 4, i64 8, i64 4, i64 4, i64 4, i64 4, i64 4, i64 0, i64 4, i64 4, i64 0, i64 1, i64 1, i64 8, i64 8, i64 6, i64 12, i64 4, i64 6, i64 24, i64 8, i64 4, i64 8, i64 9, i64 1, i64 1, i64 16, i64 16, i64 1, i64 8, i64 4, i64 8, i64 4, i64 5, i64 4, i64 4, i64 0, i64 4, i64 4, i64 1, i64 0, i64 12, i64 4, i64 12, i64 4, i64 24, i64 4, i64 40, i64 8, i64 20, i64 4, i64 8, i64 4, i64 4, i64 16, i64 4, i64 4, i64 8, i64 4, i64 8, i64 4, i64 8, i64 4, i64 4, i64 4, i64 4, i64 4, i64 4, i64 8, i64 8, i64 16, i64 16, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0], align 8

; Function Attrs: mustprogress noinline nounwind optnone
define dso_local i32 @call_trivial([1 x i32] %0) #0 {
  %2 = alloca %struct.Trivial, align 4
  %3 = alloca %struct.Trivial, align 4
  %4 = getelementptr inbounds %struct.Trivial, ptr %3, i32 0, i32 0
  store [1 x i32] %0, ptr %4, align 4
  call void @llvm.memcpy.p0.p0.i32(ptr align 4 %2, ptr align 4 %3, i32 4, i1 false)
  %5 = getelementptr inbounds %struct.Trivial, ptr %2, i32 0, i32 0
  %6 = load i32, ptr %5, align 4
  ret i32 %6
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i32(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i32, i1 immarg) #1

; Function Attrs: mustprogress noinline nounwind optnone
define dso_local void @call_nontrivial(ptr dead_on_unwind noalias writable sret(%struct.Nontrivial) align 4 %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 4
  %4 = alloca ptr, align 4
  store ptr %0, ptr %3, align 4
  store ptr %1, ptr %4, align 4
  call void @llvm.memcpy.p0.p0.i32(ptr align 4 %0, ptr align 4 %1, i32 4, i1 false)
  ret void
}

; Function Attrs: mustprogress noinline nounwind optnone
define dso_local i32 @call_trivial_abi([1 x i32] %0) #0 {
  %2 = alloca %struct.TrivialABI, align 4
  %3 = alloca %struct.TrivialABI, align 4
  %4 = getelementptr inbounds %struct.TrivialABI, ptr %3, i32 0, i32 0
  store [1 x i32] %0, ptr %4, align 4
  call void @llvm.memcpy.p0.p0.i32(ptr align 4 %2, ptr align 4 %3, i32 4, i1 false)
  %5 = call noundef ptr @_ZN10TrivialABID2Ev(ptr noundef nonnull align 4 dereferenceable(4) %3) #2
  %6 = getelementptr inbounds %struct.TrivialABI, ptr %2, i32 0, i32 0
  %7 = load i32, ptr %6, align 4
  ret i32 %7
}

; Function Attrs: mustprogress noinline nounwind optnone
define linkonce_odr dso_local noundef ptr @_ZN10TrivialABID2Ev(ptr noundef nonnull returned align 4 dereferenceable(4) %0) unnamed_addr #0 comdat align 2 {
  %2 = alloca ptr, align 4
  store ptr %0, ptr %2, align 4
  %3 = load ptr, ptr %2, align 4
  ret ptr %3
}

attributes #0 = { mustprogress noinline nounwind optnone "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="arm1022e" "target-features"="+armv5te,+dsp,+soft-float,+strict-align,-aes,-bf16,-d32,-dotprod,-fp-armv8,-fp-armv8d16,-fp-armv8d16sp,-fp-armv8sp,-fp16,-fp16fml,-fp64,-fpregs,-fullfp16,-mve,-mve.fp,-neon,-sha2,-thumb-mode,-vfp2,-vfp2sp,-vfp3,-vfp3d16,-vfp3d16sp,-vfp3sp,-vfp4,-vfp4d16,-vfp4d16sp,-vfp4sp" "use-soft-float"="true" }
attributes #1 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nounwind }

!llvm.module.flags = !{!0, !1, !2}
!llvm.ident = !{!3}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 1, !"min_enum_size", i32 4}
!2 = !{i32 7, !"frame-pointer", i32 2}
!3 = !{!"Ubuntu clang version 19.1.7 (++20250804090312+cd708029e0b2-1~exp1~20250804210325.79)"}
